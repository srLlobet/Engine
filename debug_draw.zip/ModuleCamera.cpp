#include "ModuleCamera.h"
#include "lib/MathGeoLib/Math/float4.h"
ModuleCamera::ModuleCamera()
{
}

ModuleCamera::~ModuleCamera()
{
}

bool ModuleCamera::Init()
{
 
    frustum.type = FrustumType::PerspectiveFrustum;
    //frustum.SetKind(FrustumSpaceGL, FrustumRightHanded);
    frustum.pos = float3::zero;         // Camera position
    frustum.pos = float3(0.0f, 0.0f, 6.0f);
    frustum.front = -float3::unitZ;    // Looking towards -Z
    frustum.up = float3::unitY;        // Up direction

    SetPlaneDistances(0.01f, 200.0f);
    SetFOV(pi / 4.0f, SCREEN_WIDTH / SCREEN_HEIGHT);
    //view = float4x4::identity;
    projection = frustum.ProjectionMatrix().Transposed();

    view = float4x4(frustum.ViewMatrix()).Transposed();
    /*
    glMatrixMode(GL_MODELVIEW);
    glLoadMatrixf(*viewGL.v);
    */
	return false;
}

void ModuleCamera::SetFOV(float verticalFov, float aspectRatio)
{
    frustum.verticalFov = verticalFov; // Set vertical FOV
    RecalculateHorizontalFov(aspectRatio); // Recalculate the horizontal FOV based on the vertical FOV and aspect ratio
}

void ModuleCamera::RecalculateHorizontalFov(float aspectRatio)
{
    frustum.horizontalFov = 2.f * atanf(tanf(frustum.verticalFov * 0.5f) * aspectRatio);
}

//zoom
void ModuleCamera::SetPlaneDistances(float nearPlaneDistance, float farPlaneDistance)
{
    frustum.nearPlaneDistance = nearPlaneDistance;
    frustum.farPlaneDistance = farPlaneDistance;

    projection = frustum.ProjectionMatrix().Transposed();
    
}

/*const float4x4 ModuleCamera::LookAt(const float3& cameraPosition, const float3& cameraDirection, const float3& upVector) {
    float3 zaxis = (cameraPosition - cameraDirection).Normalized();  // Camera is looking towards the target
    float3 xaxis = upVector.Cross(zaxis).Normalized();     // Right vector
    float3 yaxis = zaxis.Cross(xaxis);               // Up vector

    // Build the view matrix
    float4x4 matrix = float4x4::identity;
    matrix[0] = float4(xaxis.x, yaxis.x, zaxis.x, 0.0f);
    matrix[1] = float4(xaxis.y, yaxis.y, zaxis.y, 0.0f);
    matrix[2] = float4(xaxis.z, yaxis.z, zaxis.z, 0.0f);
    matrix[3] = float4(-xaxis.Dot(cameraPosition), -yaxis.Dot(cameraPosition), -zaxis.Dot(cameraPosition), 1.0f);

    return matrix;
}

const float4x4& ModuleCamera::GetViewMatrix() const {
    return LookAt(frustum.pos, frustum.pos + frustum.front, frustum.up);
}
*/